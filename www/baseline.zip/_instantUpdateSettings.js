function _instantUpdateSettings() {
return {
	"baseLineGUID": "abbc48022c1546429e19ca8f6b20848b",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": ""
};
}